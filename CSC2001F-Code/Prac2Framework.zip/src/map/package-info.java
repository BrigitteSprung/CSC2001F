/**
* This package contains data types for creating and manipulating maps.
*/
package map;

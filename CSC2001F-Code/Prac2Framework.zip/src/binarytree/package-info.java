/**
* This package contains foundational data types for representing and printing binary trees.
*/
package binarytree;

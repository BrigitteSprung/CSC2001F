/**
* This package contains data types for creating and manipulating  AVL binary trees.
*/
package avltree;

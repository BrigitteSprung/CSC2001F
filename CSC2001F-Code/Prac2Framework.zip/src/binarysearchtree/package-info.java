/**
* This package contains data types for creating and manipulating ordered binary trees.
*/
package binarysearchtree;

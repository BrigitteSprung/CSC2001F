import java.io.BufferedReader;
import java.io.FileReader;
//
import graph.AdjacencyMapGraph;
import graph.Vertex;
import graph.Graph;
//
import utils.ClusterBuilder;
//
import java.io.FileNotFoundException;
//
import java.util.*;

/**
 *
 * Solver for Lewis Carrol's Doublets game.
 *
 */
 public class Doublets {
 
	private Map<String, Vertex<String>> wordList;
	private Graph<String, String> graph;
	
	/**
	 * Create a Doublets object for solving problems over the words in the given file.
	 * @throws FileNotFoundException
	 */
	public Doublets(final String wordFile) throws FileNotFoundException {
		BufferedReader bf = new BufferedReader(new FileReader(wordFile));
		ClusterBuilder cb = new ClusterBuilder(bf);
		wordList = new HashMap<>();
		graph = new AdjacencyMapGraph<>();

		while (cb.hasNext()){
			List<String> cluster = cb.next();
			for (String s:cluster){
				if (!wordList.containsKey(s)){
					Vertex<String> vertex = graph.insert(s);
					wordList.put(s, vertex);
					//System.out.println("CONSTR: add to list: " + s);
				}
			}
			for (int i=0;i<cluster.size();i++){
				for (int j=i+1;j<cluster.size();j++){
					graph.insert(wordList.get(cluster.get(i)), wordList.get(cluster.get(j)), "");
				}
			}
		}
		/*
		//need to still consider if the vertex is already in the graph, but in a different cluster
		//maybe using AdjacentTo
		//check logic
		BufferedReader bf = new BufferedReader(new FileReader(wordFile));
		ClusterBuilder cb = new ClusterBuilder(bf);
		while (cb.hasNext()){
			int vertices = 0;
			List<String> cluster = cb.next();

			Vertex<String> prevV = null;
			Vertex<String> newV = null;
			for (String s : cluster) {
				if (vertices == 0) {
					prevV = graph.insert(s);
					wordList.put(s, prevV);
			 	} else if (vertices == 1){
					newV = graph.insert(s);
					graph.insert(prevV, newV, "");
					wordList.put(s,newV);
				}else {
					newV = graph.insert(s);
					graph.insert(prevV, newV, "");
					for (Vertex v : graph.getNeighbours(prevV)){
						graph.insert(v, newV, "");
						wordList.put(s, newV);
					}
					prevV = newV;
				}
				vertices++;
			}
		}*/
	}

	/**
	 * Obtain the solution to the doublet (wordOne, wordTwo).
	 * Returns null if one or other of the words is not in the lexicon.
	 * Returns an empty list if there is no solution.
	 * Otherwise returns a list of words beginning with wordOne and ending 
	 * in wordTwo, with zero or more intervening words. 
	 * <p>
	 * The list is such that (i) any adjacent pair of words in the list differ
	 * by at most one letter, and (ii) it represents the shortest route from
	 * wordOne to wordTwo.
	 */
	public List<String> solve(final String wordOne, final String wordTwo) {
		if (!wordList.containsKey(wordOne) || !wordList.containsKey(wordTwo)){
			return null;
		}
		List<Vertex<String>> list = shortestPath(wordList.get(wordOne), wordList.get(wordTwo));
		//System.out.println("SOLVE: One: " + wordOne + "Two: " + wordTwo);
		List<String> output = new ArrayList<>();
		if (list == null){
			return output;
		}
		for (Vertex<String> v : list){
			//System.out.println("SOLVE: v = " + v.toString() + "  " + v.getValue());
			output.add(v.getValue());
		}
		return output;
	}
			
	// Your code here.
	public  List<Vertex<String>> shortestPath(final Vertex<String> vOne, final Vertex<String> vTwo) {

		// Set up
		final List<List<Vertex<String>>> paths = new ArrayList<List<Vertex<String>>>();
		final List<Vertex<String>> initialPath = new ArrayList<Vertex<String>>();
		vOne.mark();
		initialPath.add(vOne);	paths.add(initialPath);
		//System.out.println("SP SET UP: v1: " + vOne.getValue() + " v2: " + vTwo.getValue());

		List<Vertex<String>> path;
		while (true) {
			path = paths.remove(0);
			//System.out.println("SP: Current path: " + path.toString());
			final Vertex<String> end = path.get(path.size()-1);
			if (end==vTwo) {
				break;
			}
			else {
				//System.out.println("SP NEIGHS: end: " + end.toString() + " neighs: " + graph.getNeighbours(end).toString());
				for(Vertex<String> neighbour : graph.getNeighbours(end)) {
					//System.out.println("SP NEIGH: end: " + end.toString() + " neigh: " + neighbour.toString());
					final List<Vertex<String>> newPath = new ArrayList<Vertex<String>>(path);
					if (!neighbour.isMarked()) {
						neighbour.mark();
						newPath.add(neighbour);
						paths.add(newPath);
					}
				}
				if (paths.isEmpty()){
					//System.out.println("Path ended early");
					return null;
				}
			}
		}
		graph.clearMarks();
		if (path.size()==1) {
			return null;
		}
		else {
			return path;
		}
	}
}

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

/**
 * Created by sprbri005 on 2016/04/20.
 */
public class DoubletSolver {
    public static void main(String[] args){
        try {
            Doublets doublet = new Doublets(args[0]);
            Scanner scanner = new Scanner(System.in);
            Scanner textScanner = new Scanner(new File(args[0]));
            int length = textScanner.next().length();

            while (scanner.hasNext()) { // change this to !="quit"
                System.out.print("Enter a doublet (two words separated by a comma), or 'quit': ");
                String line = scanner.nextLine();
                line = line.replaceAll(" ", "");
                Scanner linescanner = new Scanner(line);
                linescanner.useDelimiter(",");
                String one = linescanner.next(); //.split()?
                if (one.equals("quit")){
                    break;
                } else {
                    String two = linescanner.next();
                   // System.out.println("Word1: " + one + " Word2: " + two + " Length: " + length);
                    if (one.length()==length && two.length()==length) {
                        List<String> path = doublet.solve(one, two);
                        if (path == null || path.isEmpty()) {
                            System.out.println("Sorry, insufficient data.");
                        } else {
                            for (String s : path) {
                                System.out.println(s.toUpperCase());
                            }
                        }
                    } else {
                        System.out.println("Sorry, words must be " + length + " letters long.");
                    }
                }
            }
        }catch (FileNotFoundException e){
        }

    }
}
